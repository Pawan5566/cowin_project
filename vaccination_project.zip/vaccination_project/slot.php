<?php
	$servername = "localhost";
	$username = "pawan";
	$password = "Dbms@123";
	$dbname = "covid_vaccination";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}

	$centerid = $_POST['center_id'];
	$districtid = $_POST['district_id'];
	$aadhar_number = $_POST['aadhar'];

	$check = "SELECT center_name, vaccine_name, date, age FROM center WHERE district_id=$districtid and center_id = $centerid";
	$dosecheck = "SELECT dose1, dose2 FROM person WHERE Aadhar = $aadhar_number";
	$result = $conn->query($check);
	$doserslt = $conn->query($dosecheck);
	if ($result->num_rows > 0){
		$row = $result->fetch_assoc();
		$doserow = $doserslt->fetch_assoc();
		echo "<body style='background: linear-gradient(110deg, #fdcd3b 60%, #ffed4b 60%);height: 100vw;'>";
		$date1 = $row["date"];
		$dose_number = 1;
		$vaccinetype = $row["vaccine_name"];
		$command='';
		if(is_null($doserow["dose1"])){
			$dose_number = 1;
			$command = "INSERT INTO slot_booking values('$aadhar_number', '$date1', '$vaccinetype', '$districtid', '$centerid', '$dose_number', 0)";
		} else if (is_null($doserow["dose2"])) {
			$dose_number = 2;
			$command = "UPDATE slot_booking SET dose_no=2, has_vaccinated=0 WHERE Aadhar='$aadhar_number'";
		} else{
			exit("<h3 style='color:violet;text-align: center;margin-top:10vw;'>You have successfully taken both doses of vaccine..!</h3>");
		}
		if($conn->query($command) === TRUE){
			echo "<h3 style='color:violet;text-align: center;margin-top:10vw;'>Slot Booked Successfully!</h3>";
		}else{
			echo "<h3 style='color:violet;text-align: center;margin-top:10vw;'>An Error Occured!</h3>";
		}
	} else {
		echo "<h3 style='color:violet;text-align: center;margin-top:10vw;'>You have entered wrong choice, Please try again..!</h3>";
	}
	echo "</body>";
	$conn->close();

?> 
