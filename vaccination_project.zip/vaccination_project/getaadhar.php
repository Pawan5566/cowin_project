<?php
	session_start();
        $servername = "localhost";
        $username = "pawan";
        $password = "Dbms@123";
        $dbname = "covid_vaccination";
	        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        };
	$mobilenumber = $_POST['mobilenumber'];
        $id = $_POST['id'];
	echo "<h5>" . $mobilenumber . " " . $id . "</h5>";
	$sql = "SELECT Aadhar FROM person WHERE mobile_number='$mobilenumber' and id='$id'";
	$result = $conn->query($sql);
	if($result->num_rows > 0){
		$row = $result->fetch_assoc();
		$aadhar = $row['Aadhar'];
		header("Location: http://localhost:1200/tmp/selection.html?id=$aadhar");
	} else{
		echo "<h5>Failure</h5>";
	}

        $conn->close();

?> 
