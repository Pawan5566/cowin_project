<?php
	$servername = "localhost";
	$username = "pawan";
	$password = "Dbms@123";
	$dbname = "covid_vaccination";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}

	$fname = $_POST['firstname'] . " " . $_POST['lastname'];
	$mnumber = $_POST['mobile_number1'];
	$aadhar = $_POST['Aadhar'];
	$year = $_POST['year'];


	$check = "SELECT Aadhar FROM person where Aadhar = $aadhar";
	$result = $conn->query($check);
	if ($result->num_rows == 0){
		$sql = "INSERT INTO person(Aadhar, mobile_number, name, birth_year) values( '$aadhar', '$mnumber', '$fname', $year)";
		if ($conn->query($sql) === TRUE) {
	                echo "Registered Successfully..!";
			echo "<button><a href='http://localhost:1200/tmp/person.php?id=$mnumber'>Go Back</a></button>";
			//header("Location: http://localhost:1200/tmp/person.php?id=$mnumber");
	        } else {
	                echo "Error: " . $sql . "<br>" . $conn->error;
	        };
	} else {
		echo "<h1>User Already Exists..!</h1>";
	}

	$conn->close();

?> 
