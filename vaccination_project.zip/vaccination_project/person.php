<?php
	$servername = "localhost";
	$username = "pawan";
	$password = "Dbms@123";
	$dbname = "covid_vaccination";
	$conn = new mysqli($servername, $username, $password, $dbname);
	if ($conn->connect_error) {
		die("<h4>Connection failed: " . $conn->connect_error . "</h4>");
	}
	echo "<link rel='stylesheet' href='person.css' type='text/css'>";
	$mono = $_SERVER['REQUEST_URI'];
	$url_components = parse_url($mono);
	parse_str($url_components["query"], $params);
	$id = $params['id'];
	$sql = "SELECT id, Aadhar, name, vaccine_type FROM person where mobile_number=$id order by id";
	$result = $conn->query($sql);
	echo "<body>";
	if ($result->num_rows > 0) {
		echo "<div><table>";
		echo "<tr style='background-color: #aa96da;'><th>ID</th><th>Aadhar Number</th><th>name</th><th>Vaccine Type</th></tr>";
		while($row = $result->fetch_assoc()) {
			if(is_null($row['vaccine_type'])){
				$row['vaccine_type'] = "Not Applicable";
			}
			echo "<tr><td>" . $row["id"] . "</td><td>" . $row["Aadhar"] . "</td><td>" . $row["name"] . "</td><td>" . $row["vaccine_type"] . "</td></tr>";
		}
		echo "</table>";
	}
	else{
		echo "<h4>No Results</h4></div>";
	}
	$conn->close();
	$url = "document.location='person.html?id=" . $id . "'";
	echo "<button onclick=" .  $url . ">Add Member</button>";
	include('slot.html');
	echo "</body><br />";
?>
