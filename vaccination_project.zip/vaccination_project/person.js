function loadpage(){
	location.href = 'http://localhost:1200/tmp/person.html?id=$id';
}
