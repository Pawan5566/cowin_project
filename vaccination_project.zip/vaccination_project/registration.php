<?php
	session_start();
        $servername = "localhost";
        $username = "pawan";
        $password = "Dbms@123";
        $dbname = "covid_vaccination";
	        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        };
	$mobilenumber = $_POST['mobile_number'];
        $passwd = $_POST['password'];
	$sql = "SELECT password FROM registration WHERE mobile_number='$mobilenumber'";
	$result = $conn->query($sql);
	if ($result->num_rows == 1){
		$row = $result->fetch_assoc();
		if ($row['password'] == $passwd){
			header("Location: http://localhost:1200/tmp/person.php?id=$mobilenumber");
		} else {
			echo "<p> Sorry, That didn\t work..!</p>";
		}
	} else {
		$sql = "INSERT INTO registration values('$mobilenumber', '$passwd')";
		$conn->query($sql);
		header("Location: http://localhost:1200/tmp/person.php?id=$mobilenumber");
	};

        $conn->close();

?> 
