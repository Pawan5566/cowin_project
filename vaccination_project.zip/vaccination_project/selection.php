<?php

	$servername = "localhost";
        $username = "pawan";
        $password = "Dbms@123";
        $dbname = "covid_vaccination";
	        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        };
	$state = $_POST['state'];
        $district = $_POST['district'];
	$aadhar = $_POST['aadhar_number'];
	$sql = "SELECT district_id FROM find_district WHERE state='$state' and district='$district'";
	$result = $conn->query($sql);
        echo "<link rel='stylesheet' href='person.css' type='text/css'>";
	echo "<body style='height: 50vw;'>";
	if ($result->num_rows > 0){
                $row = $result->fetch_assoc();
                $districtid=$row["district_id"];
		echo "<div><table>";
		$sql2 = "SELECT center_id, center_name, date, vaccine_name, age FROM center WHERE district_id='$districtid'";
		$result2 = $conn->query($sql2);
		if ($result2->num_rows > 0){
	                echo "<tr style='background-color: #aa96da;'><th>Center ID</th><th>Center Name</th><th>Date</th><th>Vaccine Name</th><th>Minmum Age</th></tr>";
			while($row2 = $result2->fetch_assoc()){
				echo "<tr><td>" . $row2["center_id"] . "</td><td>" . $row2["center_name"] . "</td><td>" . $row2['date'] . "</td><td>" . $row2['vaccine_name'] . "</td><td>" . $row2['age'] . "</td></tr>";
			}
			echo "</table>";
			include('booking.html');
		}
        } else {
                echo "<h3>Sorry... Something Went Wrong..!</h3>";
        }
        $conn->close();
?> 
