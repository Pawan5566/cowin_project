<?php

	$servername = "localhost";
        $username = "pawan";
        $password = "Dbms@123";
        $dbname = "covid_vaccination";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        };
	$state = $_POST['state'];
        $district = $_POST['district'];
	$sql = "SELECT district_id FROM find_district WHERE state='$state' and district='$district'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0){
                $row = $result->fetch_assoc();
                $districtid=$row["district_id"];
		$sql2 = "SELECT center_id, center_name FROM center WHERE district_id='$districtid'";
		$result2 = $conn->query($sql2);
		if($result2->num_rows > 0){
			echo "<p> Id		Name</p>";
			while($row2 = $result2->fetch_assoc()){
				echo "<p>" . $row2['center_id'] . "   " . $row2['center_name'] . "</p>";
			}
			include('select_center.html');
		}
        } else {
                echo "<h3>Sorry... Something Went Wrong..!</h3>";
        }
        $conn->close();
?> 
