<?php

	$servername = "localhost";
        $username = "pawan";
        $password = "Dbms@123";
        $dbname = "covid_vaccination";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        };
	$centerid = $_POST['center_id'];
	$sql = "DELETE FROM center WHERE center_id='$centerid'";
	if ($conn->query($sql)){
                echo "<p>Center Deleted Sucessfully..!</p>";
        } else {
                echo "<h3>Sorry... Something Went Wrong..!</h3>";
        }
        $conn->close();
?> 
