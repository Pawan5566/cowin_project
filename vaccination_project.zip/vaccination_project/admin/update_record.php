<?php
	session_start();
        $servername = "localhost";
        $username = "pawan";
        $password = "Dbms@123";
        $dbname = "covid_vaccination";
	        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        };
	$aadhar = $_POST['aadhar'];
	$sql = "SELECT date, dose_no, vaccine_type FROM slot_booking WHERE Aadhar='$aadhar'";
	$result = $conn->query($sql);
	if($result->num_rows > 0){
		$row = $result->fetch_assoc();
		$date = $row["date"];
		$dose_no = $row["dose_no"];
		$vaccine_type = $row["vaccine_type"];
		$sql2 = '';
		if($dose_no == 1){
			$sql2 = "UPDATE person set vaccine_type='$vaccine_type', dose1='$date' WHERE Aadhar='$aadhar'";
		} else if ($dose_no == 2){
			$sql2 = "UPDATE person set vaccine_type='$vaccine_type', dose2='$date' WHERE Aadhar='$aadhar'";
		}
		if($conn->query($sql2)){
			echo "<p>Records Updated Successfully..!</p>";
			$sql3 = "UPDATE slot_booking SET has_vaccinated=1 WHERE Aadhar='$aadhar'";
			$conn->query($sql3);
		} else {
			echo "<p>Awwww...Some Error Occured..!</p>";
		}
	}
	$conn->close();

?> 
