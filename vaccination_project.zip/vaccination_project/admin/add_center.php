<?php
	session_start();
        $servername = "localhost";
        $username = "pawan";
        $password = "Dbms@123";
        $dbname = "covid_vaccination";
	        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        };
	$centername = $_POST['centername'];
        $date = $_POST['date'];
	$vaccinename = $_POST['vaccinename'];
	$districtid = $_POST['districtid'];
	$age = $_POST['age'];
	$count = $_POST['count'];
	$sql = "INSERT INTO center(center_name, district_id, date, vaccine_name, age, count) VALUES('$centername', '$districtid', '$date', '$vaccinename', '$age', '$count')";
	if($conn->query($sql)){
		echo "<p>" . "Record Added Successfully..!" . "</p>";
	} else{
		echo "<p>" . "Operation Failed..!" . "</p>";
	}
	$conn->close();

?> 
